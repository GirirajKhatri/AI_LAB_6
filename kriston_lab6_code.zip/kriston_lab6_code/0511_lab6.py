# Kriston Pal
# 0511

import operator
import re
import string
import math

from Tools.scripts.parse_html5_entities import create_dict
from tabulate import tabulate

word_list = []

def getWordList(file_name):
    # open the given document in read mode
    document_text = open(file_name, 'r')
    # store the text of the opened document
    text_string = document_text.read().lower()
    # store each word of a string text_string in list
    words = re.findall(r'\b[a-z]{1,}\b', text_string)
    stopwords = {"i",
                 "me",
                 "my",
                 "myself",
                 "we",
                 "our",
                 "ours",
                 "you",
                 "you're",
                 "you've",
                 "you'll",
                 "you'd",
                 "your",
                 "yours",
                 "yourself",
                 "yourselves",
                 "he",
                 "him",
                 "his",
                 "himself",
                 "she",
                 "she's",
                 "her",
                 "hers",
                 "herself",
                 "it",
                 "it's",
                 "its",
                 "itself",
                 "they",
                 "them",
                 "their",
                 "theirs",
                 "themselves",
                 "what",
                 "which",
                 "who",
                 "whom",
                 "this",
                 "that",
                 "that'll",
                 "these",
                 "those",
                 "am",
                 "is",
                 "are",
                 "was",
                 "were",
                 "be",
                 "been",
                 "being",
                 "have",
                 "has",
                 "had",
                 "having",
                 "do",
                 "does",
                 "did",
                 "doing",
                 "a",
                 "an",
                 "the",
                 "and",
                 "but",
                 "if",
                 "or",
                 "because",
                 "as",
                 "until",
                 "while",
                 "of",
                 "at",
                 "by",
                 "for",
                 "with",
                 "about",
                 "against",
                 "between",
                 "into",
                 "through",
                 "during",
                 "before",
                 "after",
                 "above",
                 "below",
                 "to",
                 "from",
                 "up",
                 "down",
                 "in",
                 "out",
                 "on",
                 "off",
                 "over",
                 "under",
                 "again",
                 "further",
                 "then",
                 "once",
                 "here",
                 "there",
                 "when",
                 "where",
                 "why",
                 "how",
                 "all",
                 "any",
                 "both",
                 "each",
                 "few",
                 "more",
                 "most",
                 "other",
                 "some",
                 "such",
                 "no",
                 "nor",
                 "not",
                 "only",
                 "own",
                 "same",
                 "so",
                 "than",
                 "too",
                 "very",
                 "s",
                 "t",
                 "can",
                 "will",
                 "just",
                 "don",
                 "don't",
                 "should",
                 "should've",
                 "now",
                 "d",
                 "ll",
                 "m",
                 "o",
                 "re",
                 "ve",
                 "y",
                 "ain",
                 "aren",
                 "aren't",
                 "couldn",
                 "couldn't",
                 "didn",
                 "didn't",
                 "doesn",
                 "doesn't",
                 "hadn",
                 "hadn't",
                 "hasn",
                 "hasn't",
                 "haven",
                 "haven't",
                 "isn",
                 "isn't",
                 "ma",
                 "mightn",
                 "mightn't",
                 "mustn",
                 "mustn't",
                 "needn",
                 "needn't",
                 "shan",
                 "shan't",
                 "shouldn",
                 "shouldn't",
                 "wasn",
                 "wasn't",
                 "weren",
                 "weren't",
                 "won",
                 "won't",
                 "wouldn",
                 "wouldn't"
                 }

    word_list = [w for w in words if not w in stopwords]

    word_list = []

    for w in words:
        if w not in stopwords:
            word_list.append(w)
    create_dict(word_list)
    return word_list


# def getFilteredWordList(word_list):
#     filtered_word_list = [word for word in word_list if word not in stopwords]
#     return filtered_word_list


def getWordFrequency(word_list):
    # dictionary to store word and respective frequency
    word_frequency = {}
    for word in word_list:
        count = word_frequency.get(word, 0)
        word_frequency[word] = count + 1
    return word_frequency


def findJaccardSimilarity(word_list1, word_list2):
    intersection = set(word_list1).intersection(word_list2)
    union = set(word_list1).union(word_list2)
    print("\nIntersection Set: ", intersection)
    print("Union Set: ", union)
    return len(intersection) / len(union)


def getInverseDocumentFrequency(word_frequency):
    inverse_document_frequency = {}
    for key in word_frequency:
        inverse_document_frequency[key] = math.log(4 / word_frequency[key], 2)
    return inverse_document_frequency


def getMaxFrequency(word_frequency):
    return word_frequency[max(word_frequency, key=word_frequency.get)]


def findCosineSimilarity(word_list1, word_list2):
    word_frequency1 = getWordFrequency(word_list1)
    word_frequency2 = getWordFrequency(word_list2)
    numerator_value = 0
    max_frequency_word_list1 = getMaxFrequency(word_frequency1)
    max_frequency_word_list2 = getMaxFrequency(word_frequency2)
    sum_weight_word_list1 = 0
    sum_weight_word_list2 = 0
    set_all_words = set(all_word_list)
    for word in set_all_words:
        if word in word_frequency1:
            weight_word_list1 = all_words_inverse_document_frequency[word] * word_frequency1[word] / max_frequency_word_list1
        else:
            weight_word_list1 = 0

        if word in word_frequency2:
            weight_word_list2 = all_words_inverse_document_frequency[word] * word_frequency2[word] / max_frequency_word_list2
        else:
            weight_word_list2 = 0

        sum_weight_word_list1 += math.pow(weight_word_list1, 2)
        sum_weight_word_list2 += math.pow(weight_word_list2, 2)
        numerator_value += weight_word_list1 * weight_word_list2
    denominator_value = math.sqrt(sum_weight_word_list1 * sum_weight_word_list2)
    return numerator_value / denominator_value


# Solving our problems
# document1 = 'C:\Desktop\d1.txt'
# document1 = 'C:\Desktop\d2.txt'
# document1 = 'C:\Desktop\d3.txt'
# document1 = 'C:\Desktop\d4.txt'
document1 = 'd1.txt'
document2 = 'd2.txt'
document3 = 'd3.txt'
document4 = 'd4.txt'
word_list1 = getWordList(document1)
word_list2 = getWordList(document2)
word_list3 = getWordList(document3)
word_list4 = getWordList(document4)

print("\nPART A: Finding the Jaccard similarity of each of the above documents to all other documents. \n")
print("Jaccard Similarity between Document1 and Document 2 is ",findJaccardSimilarity(word_list1,word_list2))
print("Jaccard Similarity between Document1 and Document 3 is ",findJaccardSimilarity(word_list1,word_list3))
print("Jaccard Similarity between Document1 and Document 4 is ",findJaccardSimilarity(word_list1,word_list4))
print("Jaccard Similarity between Document2 and Document 3 is ",findJaccardSimilarity(word_list2,word_list3))
print("Jaccard Similarity between Document2 and Document 4 is ",findJaccardSimilarity(word_list2,word_list4))
print("Jaccard Similarity between Document3 and Document 4 is ",findJaccardSimilarity(word_list3,word_list4))

all_word_list = list(set(word_list1))+list(set(word_list2))+list(set(word_list3))+list(set(word_list4))
all_words_frequency = getWordFrequency(all_word_list)
all_words_inverse_document_frequency = getInverseDocumentFrequency(all_words_frequency)

print("\n\n\nPART B: Finding the Cosine similarity of each of the above documents to all other documents. \n")
print("\nCosine Similarity between Document1 and Document2 is ",findCosineSimilarity(word_list1,word_list2))
print("\nCosine Similarity between Document1 and Document3 is ",findCosineSimilarity(word_list1,word_list3))
print("\nCosine Similarity between Document1 and Document4 is ",findCosineSimilarity(word_list1,word_list4))
print("\nCosine Similarity between Document2 and Document3 is ",findCosineSimilarity(word_list2,word_list3))
print("\nCosine Similarity between Document2 and Document4 is ",findCosineSimilarity(word_list2,word_list4))
print("\nCosine Similarity between Document3 and Document4 is ",findCosineSimilarity(word_list3,word_list4))